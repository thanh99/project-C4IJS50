let validate1 = false;
let validate2 = false;
let validate3 = false;
let validate4 = false;

function validateCodeOfCoupon() {
    if (document.getElementById('codeOfCoupon').value == '') {
        document.getElementById('codeOfCoupon-error').innerHTML = '<i style="color: red">Bạn chưa điền </i>';
    }
    else {
        document.getElementById('codeOfCoupon-error').innerHTML = '<i class="fa fa-check" style="color:green;"> Hoàn thành </i>';
        validate1 = true;
    }
}
function validateValueOfCoupon() {
    if (document.getElementById('valueOfCoupon').value == '') {
        document.getElementById('valueOfCoupon-error').innerHTML = '<i style="color: red">Bạn chưa điền </i>';
    }
    else if(document.getElementById('valueOfCoupon').value < 1000){
        document.getElementById('valueOfCoupon-error').innerHTML = '<i style="color: red">Giá không nhỏ hơn 1000</i>';
    }
    else {
        document.getElementById('valueOfCoupon-error').innerHTML = '<i class="fa fa-check" style="color:green;"> Hoàn thành </i>';
        validate2 = true;
    }
}

function validateTimeBOfCoupon() {
    if (document.getElementById('timeBOfCoupon').value == '') {
        document.getElementById('timeBOfCoupon-error').innerHTML = '<i style="color: red">Bạn chưa điền </i>';
    }
    else {
        document.getElementById('timeBOfCoupon-error').innerHTML = '<i class="fa fa-check" style="color:green;"> Hoàn thành </i>';
        validate3 = true;
    }
}
function validateTimeEOfCoupon() {
    if (document.getElementById('timeEOfCoupon').value == '') {
        document.getElementById('timeEOfCoupon-error').innerHTML = '<i style="color: red">Bạn chưa điền </i>';
    }
    else {
        document.getElementById('timeEOfCoupon-error').innerHTML = '<i class="fa fa-check" style="color:green;"> Hoàn thành </i>';
        validate4 = true;
    }
}
function checkCoupon(){
    if (validate1 == true && validate2 == true && validate3 == true && validate4 == true ) {
        addCoupon()
    }
    else{
        alert("chưa điền đủ thông tin")
    }
}
//------------------------------display coupon------------------------------------
function displayListCoupon() {
    let listCoupon = JSON.parse(localStorage.getItem("listCouponLocalStorage"));
    let s = "";
    for (let i = 0; i < listCoupon.length; i++) {
        const element = listCoupon[i];
        s += `<tr>
        <th scope="row">${i + 1}</th>
        <td>${element.noiDungCoupon}</td>
        <td>${element.giaTri}</td>
        <td>${element.timeB}</td>
        <td>${element.timeE}</td>
        <td>
            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#Delete" onclick="getID(${i})">
                Delete
            </button>
        </td>
    </tr>
        `
    }
    document.getElementById("list-coupon").innerHTML = s;
}
displayListCoupon();
function getID(i) {
    localStorage.setItem("ID", i);
}
// ---------------------------THEM XOA---------------------------------------
function addCoupon() {
    let listCoupon = JSON.parse(localStorage.getItem("listCouponLocalStorage"));
    listCoupon.push({
        noiDungCoupon: document.getElementById("codeOfCoupon").value,
        giaTri: document.getElementById("valueOfCoupon").value,
        timeB: document.getElementById("timeBOfCoupon").value,
        timeE: document.getElementById("timeEOfCoupon").value,
    })
    localStorage.setItem("listCouponLocalStorage", JSON.stringify(listCoupon))
    alert('Add success');
    $('#Add_new').modal('hide');
    displayListCoupon();
}
function delCoupon() {
    let listCoupon = JSON.parse(localStorage.getItem("listCouponLocalStorage"));
    let id = localStorage.getItem("ID");
    listCoupon.splice(id, 1);
    localStorage.setItem("listCouponLocalStorage", JSON.stringify(listCoupon))
    alert('Del success');
    $('#Delete').modal('hide');
    displayListCoupon();
}